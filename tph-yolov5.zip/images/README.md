# Some detection results of our methods on VisDrone and UAVDT
